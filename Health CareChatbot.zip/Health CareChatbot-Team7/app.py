from flask import Flask, render_template, request
import os
import google.generativeai as genai

# Configure Google AI SDK
genai.configure(api_key="AIzaSyC3LvTZnIBQKXhnIzpv4tcISqKqJYokOks")

# Create the model configuration
generation_config = {
    "temperature": 1,
    "top_p": 0.95,
    "top_k": 64,
    "max_output_tokens": 8192,
    "response_mime_type": "text/plain",
}

# Initialize the model
model = genai.GenerativeModel(
    model_name="gemini-1.5-flash",
    generation_config=generation_config,
    # Optionally, adjust safety settings
    system_instruction="Your name is healthbot.You need to answer only for the question related to health issues,fitness,diet plans only else dont answer",
)

# Initialize Flask app
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        user_input = request.form['user_input']
        
        # Start a chat session and get the response
        chat_session = model.start_chat(history=[])
        response = chat_session.send_message(user_input)
        
        return render_template('index.html', user_input=user_input, response=response.text)
    
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
